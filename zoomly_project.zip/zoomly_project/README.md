# zoomly_project
A vehicle management desktop application where administrators can manage backend data, and where users can make vehicle reservations based on certain parameters. 
